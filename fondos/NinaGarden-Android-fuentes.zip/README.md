# Jardín de Nina para Android

Fondo animado nativo para Android 8.0 o posterior, preparado para el Galaxy A55.
El ramo florece durante unos siete segundos y después permanece, se mece y deja
caer pétalos. Al tocar las flores se apartan suavemente y vuelven a su lugar.

## Instalar en tu Galaxy A55

1. Copia `NinaGarden.apk` al teléfono y ábrelo desde **Mis archivos**.
2. Si Android pide autorización para instalar este archivo desde esa aplicación,
   decide en la pantalla del propio teléfono. La app no cambia esa autorización.
3. Abre **Jardín de Nina** en la lista de aplicaciones.
4. Elige los colores y ajusta flores, pétalos y movimiento.
5. Pulsa **Aplicar fondo animado ♡** y confirma en la vista previa de Android.

El selector de Samsung decide las opciones de pantalla de inicio y bloqueo
disponibles según tu versión de One UI. No se modifica ninguna protección del
teléfono ni se aplica el fondo sin tu confirmación en Android.

La APK se firma con una clave local de desarrollo y no procede de Google Play.
La compilación y la firma se verifican en la computadora. **No se ha ejecutado
en un Galaxy A55 físico ni en un emulador**; el primer uso debe comprobarse en
tu dispositivo.

## Movimiento continuo y pausa

- Las flores permanecen después de crecer, sin un ciclo que las borre.
- El motor dibuja a un máximo aproximado de 30 imágenes por segundo.
- Al abrir otra aplicación o apagar la pantalla, se detiene el dibujo.
- Al volver desde una aplicación, continúa sin reiniciar el ramo.
- Si activas **Volver a florecer al encender la pantalla**, la pantalla encendida
  inicia un nuevo crecimiento, cuando el fondo vuelve a estar visible.
- La preferencia de movimiento reducido del sistema muestra el ramo completo
  y detiene los movimientos y pétalos.
- Funciona sin internet, anuncios, registro de actividad, audio ni permisos
  adicionales de usuario.

## Compilar de nuevo

Desde la carpeta principal del repositorio:

```powershell
.\.venv\Scripts\python.exe nina\wallpaper\android\build.py --prepare-tools
```

La primera ejecución descarga JDK 17 y los componentes Android 35 desde sus
distribuidores oficiales. Las huellas de `toolchain.json` verifican cada archivo.
Todo se extrae en `nina/wallpaper/.toolchain`, sin instalar programas en Windows
ni cambiar las variables de entorno del sistema. No se ejecuta `sdkmanager`
ni se aceptan licencias automáticamente.

Después puedes omitir `--prepare-tools` para reutilizar esas herramientas.
La salida queda en `android/build/NinaGarden.apk`. `verification.json` guarda
la huella SHA-256, la verificación de firma y los datos de SDK y permisos.

El código Java está en `src/com/kndez/ninagarden/`. La interfaz de ajustes usa
componentes nativos de Android y el motor dibuja en Canvas, sin un navegador
oculto. La excepción para este componente Android fue autorizada para esta tarea.

La carpeta `signing/` contiene únicamente la clave local de desarrollo y su
contraseña local. Está ignorada y no se incluye en el paquete de entrega.
Consérvala localmente si quieres firmar futuras actualizaciones con la misma
clave; no compartas esa carpeta ni la carpeta `.toolchain`.
