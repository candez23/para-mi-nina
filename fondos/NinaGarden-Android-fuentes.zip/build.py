"""Compila y firma el fondo Android con herramientas oficiales y Python estándar.

No cambia PATH ni instala programas en el sistema. No ejecuta sdkmanager ni
acepta licencias de forma automática. La clave local de desarrollo no se exporta.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
from urllib.request import Request, urlopen
import zipfile

ROOT = Path(__file__).resolve().parent
TOOLS = ROOT.parent / ".toolchain"
BUILD = ROOT / "build"


def prepare_tools() -> None:
    """Descarga archivos oficiales ya identificados y comprueba sus huellas."""
    manifest = json.loads((ROOT / "toolchain.json").read_text(encoding="utf-8"))
    downloads = TOOLS / "downloads"
    downloads.mkdir(parents=True, exist_ok=True)

    def fetch(item):
        folder = item["folder"]
        archive = downloads / (folder + ".zip")
        algorithm, expected = item["algorithm"], item["checksum"]
        if not archive.exists() or hashlib.new(algorithm, archive.read_bytes()).hexdigest() != expected:
            print("Descargando herramienta oficial: " + folder, flush=True)
            request = Request(item["url"], headers={"User-Agent": "NinaGardenBuild/1.0"})
            with urlopen(request, timeout=120) as response, archive.open("wb") as target:
                while chunk := response.read(1024 * 1024):
                    target.write(chunk)
        if hashlib.new(algorithm, archive.read_bytes()).hexdigest() != expected:
            raise RuntimeError("La huella de la descarga no coincide: " + folder)
        destination = (TOOLS / folder).resolve()
        destination.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive) as bundle:
            for name in bundle.namelist():
                if not (destination / name).resolve().is_relative_to(destination):
                    raise RuntimeError("Ruta inválida en herramienta: " + name)
            bundle.extractall(destination)

    with ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(fetch, manifest))
    (TOOLS / ".gitignore").write_text("*\n", encoding="utf-8")


def locate(folder: str, filename: str) -> Path:
    results = sorted((TOOLS / folder).rglob(filename))
    if not results:
        raise RuntimeError(f"Falta {filename}; ejecuta build.py --prepare-tools")
    return results[0]


def build() -> Path:
    javac = locate("jdk", "javac.exe")
    java = javac.with_name("java.exe")
    keytool = javac.with_name("keytool.exe")
    android_jar = locate("platform", "android.jar")
    aapt = locate("build-tools", "aapt2.exe")
    zipalign = locate("build-tools", "zipalign.exe")
    d8 = locate("build-tools", "d8.jar")
    signer = locate("build-tools", "apksigner.jar")
    BUILD.mkdir(parents=True, exist_ok=True)
    generated, classes, dex = (BUILD / "generated", BUILD / "classes", BUILD / "dex")
    for directory in (generated, classes, dex):
        directory.mkdir(exist_ok=True)
    env = os.environ.copy()
    env["JAVA_HOME"] = str(java.parent.parent)
    env["PATH"] = str(java.parent) + os.pathsep + env.get("PATH", "")

    def run(label: str, args: list[str | Path]) -> str:
        print(label, flush=True)
        result = subprocess.run([str(arg) for arg in args], cwd=ROOT, env=env, capture_output=True, encoding="utf-8", errors="replace")
        if result.returncode:
            raise RuntimeError(label + "\n" + result.stdout + result.stderr)
        return result.stdout + result.stderr

    resources = BUILD / "resources.zip"
    run("Compilando recursos", [aapt, "compile", "--dir", ROOT / "res", "-o", resources])
    base = BUILD / "base.apk"
    run("Enlazando manifiesto", [aapt, "link", "-o", base, "--manifest", ROOT / "AndroidManifest.xml", "-I", android_jar, "--java", generated, "--min-sdk-version", "26", "--target-sdk-version", "35", "--auto-add-overlay", resources])
    sources = sorted((ROOT / "src").rglob("*.java")) + sorted(generated.rglob("*.java"))
    run("Compilando código Android", [javac, "-encoding", "UTF-8", "-source", "8", "-target", "8", "-classpath", android_jar, "-d", classes, *sources])
    class_jar = BUILD / "classes.jar"
    with zipfile.ZipFile(class_jar, "w", zipfile.ZIP_DEFLATED) as output:
        for path in sorted(classes.rglob("*.class")):
            output.write(path, path.relative_to(classes).as_posix())
    run("Generando DEX", [java, "-cp", d8, "com.android.tools.r8.D8", "--min-api", "26", "--lib", android_jar, "--output", dex, class_jar])
    unsigned = BUILD / "unsigned.apk"
    with zipfile.ZipFile(base) as resource_apk, zipfile.ZipFile(unsigned, "w", zipfile.ZIP_DEFLATED) as output:
        for info in resource_apk.infolist():
            output.writestr(info, resource_apk.read(info.filename))
        for path in sorted(dex.glob("*.dex")):
            output.write(path, path.name)
    aligned = BUILD / "aligned.apk"
    run("Alineando APK", [zipalign, "-f", "-p", "4", unsigned, aligned])

    signing = ROOT / "signing"
    signing.mkdir(exist_ok=True)
    password_path = signing / "local-password.txt"
    if not password_path.exists():
        password_path.write_text(secrets.token_urlsafe(32), encoding="utf-8")
    env["NINA_DEBUG_STOREPASS"] = password_path.read_text(encoding="utf-8").strip()
    keystore = signing / "nina-development.p12"
    if not keystore.exists():
        run("Creando firma local de desarrollo", [keytool, "-genkeypair", "-keystore", keystore, "-storetype", "PKCS12", "-alias", "nina-development", "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000", "-dname", "CN=Nina Garden Development,OU=Local,O=Personal,C=MX", "-storepass:env", "NINA_DEBUG_STOREPASS", "-keypass:env", "NINA_DEBUG_STOREPASS"])
    apk = BUILD / "NinaGarden.apk"
    run("Firmando APK", [java, "-jar", signer, "sign", "--ks", keystore, "--ks-key-alias", "nina-development", "--ks-pass", "env:NINA_DEBUG_STOREPASS", "--key-pass", "env:NINA_DEBUG_STOREPASS", "--out", apk, aligned])
    signature = run("Verificando firma", [java, "-jar", signer, "verify", "--verbose", "--print-certs", apk])
    badging = run("Verificando paquete y permisos", [aapt, "dump", "badging", apk])
    if "uses-permission:" in badging:
        raise RuntimeError("Se detectó un permiso no previsto en el APK")
    with zipfile.ZipFile(apk) as bundle:
        assert "AndroidManifest.xml" in bundle.namelist()
        assert "classes.dex" in bundle.namelist()
    verification = {"package": "com.kndez.ninagarden", "version": "1.0", "min_sdk": 26, "target_sdk": 35, "apk_bytes": apk.stat().st_size, "sha256": hashlib.sha256(apk.read_bytes()).hexdigest(), "signature_verified": True, "permissions": [], "physical_device_tested": False, "signature_report": signature.strip(), "package_report": badging.strip()}
    (BUILD / "verification.json").write_text(json.dumps(verification, ensure_ascii=False, indent=2), encoding="utf-8")
    print("APK listo: " + str(apk), flush=True)
    print("SHA-256: " + verification["sha256"], flush=True)
    return apk


def main() -> None:
    parser = argparse.ArgumentParser(description="Compilar Jardín de Nina para Android")
    parser.add_argument("--prepare-tools", action="store_true", help="Descargar y verificar las herramientas oficiales dentro del proyecto")
    args = parser.parse_args()
    if args.prepare_tools:
        prepare_tools()
    build()


if __name__ == "__main__":
    main()
