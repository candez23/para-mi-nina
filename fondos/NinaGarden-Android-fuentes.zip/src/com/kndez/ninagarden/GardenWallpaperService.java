package com.kndez.ninagarden;

import android.animation.ValueAnimator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

/** Fondo nativo: sin red, WebView, servicios remotos ni permisos adicionales. */
public final class GardenWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new GardenEngine(); }

    final class GardenEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final GardenRenderer garden = new GardenRenderer();
        private final SharedPreferences prefs = getSharedPreferences("garden", MODE_PRIVATE);
        private boolean visible, surfaceReady, destroyed, screenAwake, regrowPending;
        private long lastFrame;

        private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                    screenAwake = false;
                    handler.removeCallbacks(drawFrame);
                    lastFrame = 0;
                } else if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) {
                    screenAwake = true;
                    regrowPending = prefs.getBoolean("regrow", true);
                    schedule();
                }
            }
        };

        private final Runnable drawFrame = new Runnable() {
            @Override public void run() {
                handler.removeCallbacks(this);
                if (!canDraw()) return;
                if (regrowPending) { garden.regrow(); regrowPending = false; }
                boolean reduced = prefs.getBoolean("respectMotion", true) && !ValueAnimator.areAnimatorsEnabled();
                long now = SystemClock.uptimeMillis();
                float dt = lastFrame == 0 ? 0 : Math.min(.05f, (now - lastFrame) / 1000f);
                lastFrame = now;
                garden.update(dt, reduced);
                Canvas canvas = null;
                try {
                    canvas = getSurfaceHolder().lockCanvas();
                    if (canvas != null) garden.draw(canvas);
                } catch (IllegalArgumentException | IllegalStateException ignored) {
                    // La superficie puede desaparecer entre el callback y lockCanvas.
                } finally {
                    if (canvas != null) getSurfaceHolder().unlockCanvasAndPost(canvas);
                }
                if (canDraw() && !reduced) handler.postDelayed(this, Math.max(1, 33 - (SystemClock.uptimeMillis() - now)));
            }
        };

        @Override public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            setTouchEventsEnabled(true);
            PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
            screenAwake = power == null || power.isInteractive();
            prefs.registerOnSharedPreferenceChangeListener(this);
            configure();
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_ON); filter.addAction(Intent.ACTION_SCREEN_OFF);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(screenReceiver, filter);
        }

        private boolean canDraw() { return visible && screenAwake && surfaceReady && !destroyed; }
        private void schedule() {
            handler.removeCallbacks(drawFrame);
            if (canDraw()) handler.post(drawFrame);
        }
        private void configure() {
            garden.configure(prefs.getInt("theme", 0), prefs.getInt("density", 100) / 100f,
                prefs.getBoolean("petals", true), prefs.getInt("motion", 80) / 100f);
        }
        @Override public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            configure(); schedule();
        }
        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            lastFrame = 0;
            schedule();
        }
        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            garden.resize(width, height);
            surfaceReady = true;
            lastFrame = 0;
            schedule();
        }
        @Override public void onSurfaceRedrawNeeded(SurfaceHolder holder) { schedule(); }
        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            surfaceReady = false; lastFrame = 0; handler.removeCallbacks(drawFrame);
            super.onSurfaceDestroyed(holder);
        }
        @Override public void onTouchEvent(MotionEvent event) {
            garden.touch(event.getX(), event.getY(), event.getActionMasked());
            super.onTouchEvent(event);
        }
        @Override public void onDestroy() {
            destroyed = true; handler.removeCallbacksAndMessages(null);
            prefs.unregisterOnSharedPreferenceChangeListener(this);
            try { unregisterReceiver(screenReceiver); } catch (IllegalArgumentException ignored) { }
            garden.release();
            super.onDestroy();
        }
    }
}
