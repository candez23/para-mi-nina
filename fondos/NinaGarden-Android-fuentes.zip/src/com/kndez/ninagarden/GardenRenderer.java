package com.kndez.ninagarden;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Random;

/** Dibujo original, determinista y persistente; toda simulación usa tiempo visible. */
public final class GardenRenderer {
    private static final float TAU = (float) (Math.PI * 2);
    private static final int[][] COLORS = {
        {0xfffff1e6,0xffeeaca6,0xffc67888,0xffb9697c},
        {0xfff9e2e8,0xffd99ab1,0xffad627f,0xff9d5a74},
        {0xfffff9eb,0xfff3e0c2,0xffdcb898,0xffc8a58a},
        {0xfff5dbe2,0xffc883a0,0xff9e617e,0xff8e526e},
        {0xfffff1e2,0xfff1bca6,0xffd38b7c,0xffbb8075},
        {0xfffff6ee,0xfff9e9dc,0xffdec8b6,0xffc9b4a2},
        {0xffffe8e5,0xffe69ea3,0xffba6079,0xffb35f75},
        {0xfff6e9ef,0xffceb2c8,0xffa382a2,0xff97728f}
    };
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path path = new Path();
    private final RectF spriteBounds = new RectF();
    private final ArrayList<Flower> flowers = new ArrayList<>();
    private final ArrayList<Petal> petals = new ArrayList<>();
    private final Random random = new Random(104729);
    private final Bitmap[] sprites = new Bitmap[8];
    private int pixelWidth, pixelHeight, theme, background;
    private float width, height, scale = 1, density = 1, motion = .8f;
    private float visibleTime, spawnTime, pointerX, pointerY, pointerUntil = -1;
    private float centerX, centerY, radiusX, radiusY, rootY;
    private boolean petalsEnabled = true, reduced;
    private Shader halo;

    private static final class Flower {
        float x,y,homeX,homeY,vx,vy,radius,phase,rotation,birth,rootX,rootY;
        int sprite; boolean leaf;
    }
    private static final class Petal {
        float x,y,vx,vy,angle,spin,size,life,total,phase;
        int color;
    }

    public GardenRenderer() { makeSprites(); }
    public void configure(int nextTheme, float nextDensity, boolean nextPetals, float nextMotion) {
        nextTheme = Math.max(0, Math.min(2, nextTheme));
        nextDensity = clamp(nextDensity, .6f, 1.4f);
        boolean relayout = nextDensity != density;
        theme = nextTheme; density = nextDensity;
        petalsEnabled = nextPetals; motion = clamp(nextMotion,.4f,1.4f);
        if (!petalsEnabled) petals.clear();
        if (pixelWidth > 0) { setBackground(); if (relayout) layout(); }
    }
    public void resize(int nextWidth, int nextHeight) {
        if (nextWidth <= 0 || nextHeight <= 0) return;
        pixelWidth=nextWidth; pixelHeight=nextHeight;
        scale=Math.max(1,Math.min(nextWidth,nextHeight)/400f);
        width=nextWidth/scale; height=nextHeight/scale;
        layout(); setBackground();
    }
    private void setBackground() {
        background=theme==1?0xff211a29:theme==2?0xffedf2e8:0xfffaf5ee;
        int glow=theme==1?0x554f314d:theme==2?0x38c6d2b5:0x55e9c7c4;
        halo=new RadialGradient(centerX,centerY,Math.max(width*.73f,height*.35f),new int[]{glow,0x00000000},null,Shader.TileMode.CLAMP);
    }
    private void layout() {
        boolean portrait=height>=width;
        centerX=portrait?width*.5f:width*.64f;
        centerY=portrait?height*.56f:height*.43f;
        radiusX=portrait?width*.43f:Math.min(width*.28f,height*.44f);
        radiusY=portrait?Math.min(width*.37f,height*.17f):height*.25f;
        rootY=height*(portrait?.88f:.88f);
        flowers.clear(); petals.clear();
        int count=Math.round(146*density);
        for(int i=0;i<count;i++) {
            double angle=i*2.399963229728653;
            float ring=(float)Math.sqrt((i+.5)/count);
            Flower f=new Flower();
            f.homeX=centerX+(float)Math.cos(angle)*radiusX*ring;
            f.homeY=centerY+(float)Math.sin(angle)*radiusY*ring;
            f.x=f.homeX;f.y=f.homeY;f.phase=i*1.93f;
            f.radius=12.0f+(1-ring)*10+(i%4)*1.1f;
            f.rotation=(float)Math.sin(i*7.3)*.36f;
            f.sprite=i%8; f.leaf=i%3==0;
            f.rootX=centerX+(float)Math.sin(i*1.79)*width*.034f;
            f.rootY=rootY+(float)Math.cos(i*2.13)*3.5f;
            flowers.add(f);
        }
        Collections.sort(flowers,new Comparator<Flower>() {public int compare(Flower a,Flower b){return Float.compare(b.homeY,a.homeY);}});
        for(int i=0;i<flowers.size();i++)flowers.get(i).birth=i/(float)Math.max(1,flowers.size()-1)*5.8f;
        Collections.reverse(flowers);
    }
    public void regrow() { visibleTime=0;spawnTime=0;pointerUntil=-1;pointerX=0;pointerY=0;petals.clear(); for(Flower f:flowers){f.x=f.homeX;f.y=f.homeY;f.vx=0;f.vy=0;} }
    public void completeGrowth() { visibleTime=9; }
    public void touch(float x,float y,int action) {
        pointerX=x/scale;pointerY=y/scale;
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_MOVE)pointerUntil=visibleTime+.85f;
        else pointerUntil=visibleTime+.25f;
    }
    public void update(float delta,boolean reduceMotion) {
        reduced=reduceMotion;
        float dt=clamp(delta,0,.05f);
        if(reduced){visibleTime=Math.max(visibleTime,9);petals.clear();return;}
        visibleTime+=dt;
        for(Flower f:flowers) {
            float wind=(float)Math.sin(visibleTime*.55+f.phase)*1.7f*motion;
            float ax=(f.homeX+wind-f.x)*18-f.vx*6.8f;
            float ay=(f.homeY+(float)Math.cos(visibleTime*.4+f.phase)*.7f*motion-f.y)*18-f.vy*6.8f;
            if(visibleTime<pointerUntil) {
                float dx=f.x-pointerX,dy=f.y-pointerY,d=(float)Math.hypot(dx,dy);
                if(d<76&&d>.01f){float force=(float)Math.pow(1-d/76,2)*1250*motion;ax+=dx/d*force;ay+=dy/d*force;}
            }
            f.vx+=ax*dt;f.vy+=ay*dt;f.x+=f.vx*dt;f.y+=f.vy*dt;
        }
        if(petalsEnabled&&visibleTime>4) {
            spawnTime+=dt;
            if(spawnTime>.48f&&petals.size()<42){spawnTime=0;spawnPetal();}
        }
        Iterator<Petal> iterator=petals.iterator();
        while(iterator.hasNext()) {
            Petal p=iterator.next();p.life-=dt;
            p.x+=(p.vx+(float)Math.sin(visibleTime*.6+p.phase)*5)*dt*motion;
            p.vy=Math.min(26,p.vy+1.4f*dt);p.y+=p.vy*dt*motion;p.angle+=p.spin*dt*motion;
            if(p.life<=0||p.y>height+25)iterator.remove();
        }
    }
    private void spawnPetal() {
        Petal p=new Petal();
        if(random.nextFloat()<.68f&&!flowers.isEmpty()) {
            Flower f=flowers.get(random.nextInt(flowers.size()));p.x=f.x;p.y=f.y;
        }else{p.x=random.nextFloat()*width;p.y=-12;}
        p.vx=(random.nextFloat()-.5f)*8;p.vy=9+random.nextFloat()*9;
        p.size=2.7f+random.nextFloat()*3.5f;p.angle=random.nextFloat()*TAU;p.spin=(random.nextFloat()-.5f)*.8f;
        p.life=p.total=24+random.nextFloat()*17;p.phase=random.nextFloat()*TAU;
        p.color=COLORS[random.nextInt(8)][1];petals.add(p);
    }
    public void draw(Canvas canvas) {
        canvas.save();canvas.scale(scale,scale);canvas.drawColor(background);
        paint.setStyle(Paint.Style.FILL);paint.setAlpha(255);paint.setShader(halo);
        canvas.drawRect(0,0,width,height,paint);paint.setShader(null);
        // Polvo dorado, estable y muy tenue; la parte superior queda libre para el reloj.
        for(int i=0;i<18;i++) {
            float alpha=reduced?.16f:.10f+.07f*(float)Math.sin(visibleTime*.4+i*1.8);
            paint.setColor(theme==1?0xffe7cd93:0xffc5a782);paint.setAlpha((int)(alpha*255));
            canvas.drawCircle(width*((i*.618033f)%1),height*(.26f+(i*.319f%1)*.67f),i%3==0?.85f:.45f,paint);
        }
        paint.setAlpha(255);paint.setColor(theme==1?0x18463045:0x0d896956);
        canvas.drawOval(centerX-width*.16f,rootY+height*.027f,centerX+width*.16f,rootY+height*.046f,paint);
        for(Flower f:flowers)drawStem(canvas,f);
        drawRibbon(canvas);
        for(Flower f:flowers)drawFlower(canvas,f);
        for(Petal p:petals)drawPetal(canvas,p);
        paint.setAlpha(255);paint.setShader(null);canvas.restore();
    }
    private float growth(Flower f) {
        float t=clamp((visibleTime-f.birth)/1.45f,0,1);
        return 1-(1-t)*(1-t)*(1-t);
    }
    private void drawStem(Canvas c,Flower f) {
        float g=growth(f);if(g<=0)return;
        float x=f.rootX+(f.x-f.rootX)*g,y=f.rootY+(f.y-f.rootY)*g;
        float bend=(x-f.rootX)*.18f;
        path.reset();path.moveTo(f.rootX,f.rootY);path.cubicTo(f.rootX-bend,f.rootY-45,x+bend,y+55,x,y);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.7f);paint.setColor(theme==1?0x897f9476:0x70788b68);paint.setAlpha((int)(Math.min(1,g*2)*Color.alpha(paint.getColor())));c.drawPath(path,paint);
        if(f.leaf&&g>.68f) {
            float leafX=f.rootX+(x-f.rootX)*.42f,leafY=f.rootY+(y-f.rootY)*.42f;
            c.save();c.translate(leafX,leafY);c.rotate((f.sprite%2==0?-1:1)*(40+f.rotation*20));
            path.reset();path.moveTo(0,0);path.cubicTo(-6,-7,-4,-16,0,-18);path.cubicTo(7,-12,6,-3,0,0);
            paint.setStyle(Paint.Style.FILL);paint.setColor(theme==1?0x998ea67d:0x708e9c77);c.drawPath(path,paint);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.5f);paint.setColor(0x8084946b);c.drawLine(0,0,0,-16,paint);c.restore();
        }
        paint.setAlpha(255);paint.setStyle(Paint.Style.FILL);
    }
    private void drawFlower(Canvas c,Flower f) {
        float g=growth(f);if(g<=0)return;
        float x=f.rootX+(f.x-f.rootX)*g,y=f.rootY+(f.y-f.rootY)*g;
        float size=f.radius*g;
        c.save();c.translate(x,y);c.rotate((f.rotation+f.vx*.0015f+(1-g)*.6f)*180/(float)Math.PI);
        paint.setAlpha((int)(Math.min(1,g*1.8f)*255));
        spriteBounds.set(-size,-size,size,size);
        c.drawBitmap(sprites[f.sprite],null,spriteBounds,paint);
        paint.setAlpha(255);c.restore();
    }
    private void drawRibbon(Canvas c) {
        float amount=clamp((visibleTime-.5f)/2,0,1);if(amount<=0)return;
        float x=centerX,y=rootY-5;
        path.reset();path.moveTo(x-7,y);path.cubicTo(x-44,y-24,x-44,y+14,x-4,y+6);path.cubicTo(x+44,y+15,x+43,y-20,x+8,y);
        path.cubicTo(x-2,y+5,x-3,y+27,x-19,y+33);path.moveTo(x+3,y+5);path.quadTo(x+7,y+25,x+26,y+29);
        paint.setColor(theme==1?0xffd1a0ad:0xffb46e85);paint.setAlpha((int)(amount*215));paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.05f);c.drawPath(path,paint);paint.setAlpha(255);paint.setStyle(Paint.Style.FILL);
    }
    private void drawPetal(Canvas c,Petal p) {
        float opacity=Math.min(1,p.life/4)*Math.min(1,(p.total-p.life)/1.4f)*.68f;
        c.save();c.translate(p.x,p.y);c.rotate(p.angle*180/(float)Math.PI);
        c.scale(1,.55f+.45f*(float)Math.abs(Math.cos(p.angle)));
        path.reset();path.moveTo(-p.size,0);path.cubicTo(-p.size,-p.size*1.2f,p.size*.5f,-p.size*1.8f,p.size,0);path.cubicTo(p.size*.7f,p.size*.8f,-p.size*.2f,p.size*.6f,-p.size,0);
        paint.setColor(p.color);paint.setAlpha((int)(opacity*255));c.drawPath(path,paint);paint.setAlpha(255);c.restore();
    }
    private void makeSprites() {
        for(int i=0;i<sprites.length;i++) {
            Bitmap bitmap=Bitmap.createBitmap(256,256,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(bitmap);c.translate(128,128);c.scale(1.7f,1.7f);
            int[] colors=COLORS[i];boolean daisy=i==2||i==5;int count=daisy?12:9;
            Shader petalPaint=new LinearGradient(-34,-51,31,17,new int[]{colors[0],colors[1],colors[2]},new float[]{0,.55f,1},Shader.TileMode.CLAMP);
            for(int n=0;n<count;n++) {
                c.save();c.rotate(n*360f/count+(i%3==2?11:0));path.reset();
                if(daisy)path.addOval(-9,-54,9,0,Path.Direction.CW);
                else{path.moveTo(0,6);path.cubicTo(-17,-4,-33,-30,-24,-48);path.cubicTo(-17,-63,-3,-61,0,-51);path.cubicTo(8,-66,25,-57,27,-44);path.cubicTo(30,-23,12,-3,0,6);}
                paint.setStyle(Paint.Style.FILL);paint.setShader(petalPaint);c.drawPath(path,paint);paint.setShader(null);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.65f);paint.setColor(colors[3]);c.drawPath(path,paint);
                path.reset();path.moveTo(0,-9);path.quadTo(-5,-27,0,daisy?-45:-49);paint.setAlpha(105);paint.setStrokeWidth(.55f);c.drawPath(path,paint);paint.setAlpha(255);c.restore();
            }
            paint.setStyle(Paint.Style.FILL);paint.setShader(null);paint.setColor(daisy?0xffad9259:0xff6c314b);c.drawCircle(0,0,daisy?11:10,paint);
            paint.setColor(0xffd9b575);c.drawCircle(0,0,5.5f,paint);paint.setColor(0xfffff2cb);
            for(int n=0;n<7;n++)c.drawCircle((float)Math.cos(n*TAU/7)*6.7f,(float)Math.sin(n*TAU/7)*6.7f,1.2f,paint);
            sprites[i]=bitmap;
        }
    }
    public void release(){for(Bitmap sprite:sprites)if(sprite!=null&&!sprite.isRecycled())sprite.recycle();}
    private static float clamp(float value,float min,float max){return Math.max(min,Math.min(max,value));}
}
