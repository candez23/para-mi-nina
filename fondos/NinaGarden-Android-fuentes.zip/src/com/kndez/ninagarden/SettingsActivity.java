package com.kndez.ninagarden;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/** Ajustes locales; la elección final del fondo se hace en la pantalla de Android. */
public final class SettingsActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout content;
    private GardenPreview preview;
    private final int ink=0xff592b3e,rose=0xff994963,muted=0xff80656c;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("garden",MODE_PRIVATE);
        getWindow().setStatusBarColor(0xfffaf5ee);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xfffaf5ee);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(25),dp(26),dp(25),dp(30));
        scroll.addView(content,new ScrollView.LayoutParams(-1,-2));setContentView(scroll);
        scroll.setOnApplyWindowInsetsListener((v,insets)->{
            int top,bottom;
            if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());top=bars.top;bottom=bars.bottom;}
            else{top=insets.getSystemWindowInsetTop();bottom=insets.getSystemWindowInsetBottom();}
            content.setPadding(dp(25),dp(22)+top,dp(25),dp(28)+bottom);return insets;
        });
        text("UN RAMO QUE PERMANECE",10,rose,false,8);
        TextView title=text("Jardín de Nina",31,ink,true,10);title.setTypeface(Typeface.create("serif",Typeface.NORMAL));
        text("Flores que nacen con calma, se mecen contigo y siguen aquí mientras caen pétalos.",14,muted,false,18);
        preview=new GardenPreview();content.addView(preview,new LinearLayout.LayoutParams(-1,dp(345)));
        text("Hazlo tuyo",22,ink,true,10);
        text("Color del jardín",13,muted,false,5);
        Spinner themes=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,new String[]{"Rosa y marfil","Noche de pétalos","Salvia y luz"});adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);themes.setAdapter(adapter);themes.setSelection(prefs.getInt("theme",0));
        content.addView(themes,new LinearLayout.LayoutParams(-1,dp(48)));
        themes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> parent){} public void onItemSelected(AdapterView<?> parent,View view,int position,long id){prefs.edit().putInt("theme",position).apply();refresh();}});
        slider("Flores en el ramo","density",60,140,100);
        slider("Movimiento suave","motion",40,140,80);
        checkbox("Dejar caer pétalos","petals",true);
        checkbox("Volver a florecer al encender la pantalla","regrow",true);
        checkbox("Respetar el movimiento reducido del sistema","respectMotion",true);
        Button apply=new Button(this);apply.setText("Aplicar fondo animado ♡");apply.setTextColor(0xfffff5e9);apply.setTextSize(14);apply.setAllCaps(false);apply.setMinHeight(dp(54));
        GradientDrawable background=new GradientDrawable();background.setColor(rose);background.setCornerRadius(dp(9));apply.setBackground(background);
        LinearLayout.LayoutParams buttonParams=new LinearLayout.LayoutParams(-1,dp(56));buttonParams.topMargin=dp(20);buttonParams.bottomMargin=dp(14);content.addView(apply,buttonParams);
        apply.setOnClickListener(v->{
            Intent intent=new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,new ComponentName(this,GardenWallpaperService.class));
            try{startActivity(intent);}catch(ActivityNotFoundException e){try{startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));}catch(ActivityNotFoundException ignored){Toast.makeText(this,"Este dispositivo no mostró el selector de fondos animados",Toast.LENGTH_LONG).show();}}
        });
        text("Android mostrará una vista previa y te dejará elegir dónde aplicarlo. Las opciones de pantalla de bloqueo dependen de tu versión de One UI.",12,muted,false,14);
        text("Todo vive en tu celular, sin conexión, anuncios ni música. La animación descansa cuando no se ve.",12,muted,false,0);
    }
    private TextView text(String value,int size,int color,boolean bold,int bottom){
        TextView view=new TextView(this);view.setText(value);view.setTextColor(color);view.setTextSize(size);view.setLineSpacing(dp(3),1.1f);if(bold)view.setTypeface(null,Typeface.BOLD);
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,-2);params.bottomMargin=dp(bottom);content.addView(view,params);return view;
    }
    private void checkbox(String label,String key,boolean fallback){
        CheckBox box=new CheckBox(this);box.setText(label);box.setTextSize(13);box.setTextColor(ink);box.setMinHeight(dp(49));box.setChecked(prefs.getBoolean(key,fallback));content.addView(box,new LinearLayout.LayoutParams(-1,-2));
        box.setOnCheckedChangeListener((button,checked)->{prefs.edit().putBoolean(key,checked).apply();refresh();});
    }
    private void slider(String label,String key,int min,int max,int fallback){
        TextView title=text(label+" · "+prefs.getInt(key,fallback)+"%",13,muted,false,0);
        SeekBar seek=new SeekBar(this);seek.setMax(max-min);seek.setProgress(prefs.getInt(key,fallback)-min);content.addView(seek,new LinearLayout.LayoutParams(-1,dp(48)));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(SeekBar bar){} public void onStopTrackingTouch(SeekBar bar){refresh();}
            public void onProgressChanged(SeekBar bar,int progress,boolean user){if(user){int value=progress+min;title.setText(label+" · "+value+"%");prefs.edit().putInt(key,value).apply();refresh();}}
        });
    }
    private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private void refresh(){if(preview!=null)preview.configure();}
    @Override public void onResume(){super.onResume();if(preview!=null)preview.start();}
    @Override public void onPause(){if(preview!=null)preview.stop();super.onPause();}
    @Override public void onDestroy(){if(preview!=null)preview.release();super.onDestroy();}

    private final class GardenPreview extends View {
        private final GardenRenderer garden=new GardenRenderer();
        private final Handler handler=new Handler(Looper.getMainLooper());
        private long last;
        private boolean running;
        private final Runnable frame=new Runnable(){public void run(){if(!running)return;long now=SystemClock.uptimeMillis();boolean reduced=prefs.getBoolean("respectMotion",true)&&!ValueAnimator.areAnimatorsEnabled();garden.update(last==0?0:Math.min(.05f,(now-last)/1000f),reduced);last=now;invalidate();if(!reduced)handler.postDelayed(this,33);}};
        GardenPreview(){super(SettingsActivity.this);garden.completeGrowth();configure();setContentDescription("Vista previa del ramo, responde suavemente al tocarlo");}
        void configure(){garden.configure(prefs.getInt("theme",0),prefs.getInt("density",100)/100f,prefs.getBoolean("petals",true),prefs.getInt("motion",80)/100f);invalidate();if(running){handler.removeCallbacks(frame);handler.post(frame);}}
        void start(){stop();running=true;last=0;handler.post(frame);}void stop(){running=false;handler.removeCallbacksAndMessages(null);last=0;}
        void release(){stop();garden.release();}
        @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){garden.resize(w,h);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);garden.draw(c);}
        @Override public boolean onTouchEvent(android.view.MotionEvent event){garden.touch(event.getX(),event.getY(),event.getActionMasked());return true;}
    }
}
